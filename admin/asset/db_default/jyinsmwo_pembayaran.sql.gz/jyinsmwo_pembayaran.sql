CREATE DATABASE IF NOT EXISTS `jyinsmwo_pembayaran`;

USE `jyinsmwo_pembayaran`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `tb_baak`;

CREATE TABLE `tb_baak` (
  `id_pegawai` int(11) NOT NULL AUTO_INCREMENT,
  `nip` varchar(11) NOT NULL,
  `nama_pegawai` varchar(50) NOT NULL,
  `jabatan` varchar(11) NOT NULL,
  `foto` varchar(50) NOT NULL,
  PRIMARY KEY (`id_pegawai`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `tb_info`;

CREATE TABLE `tb_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(55) DEFAULT NULL,
  `alamat` varchar(100) DEFAULT NULL,
  `kode_pos` varchar(11) DEFAULT NULL,
  `telp` varchar(20) DEFAULT NULL,
  `icon` varchar(20) DEFAULT NULL,
  `logo` varchar(55) DEFAULT NULL,
  `banner` varchar(20) DEFAULT NULL,
  `banner_admin` varchar(20) DEFAULT NULL,
  `info1` varchar(255) DEFAULT NULL,
  `info2` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO tb_info VALUES("2","SMK MIFTAHUL ULUMBOARDING SCHOOL","JL.P.Diponegoro No.17 Jogoloyo Wonosalam Demak Jawa Tengah","59571","081326030114","icon.png","logo.jpg","banner.png","banner_admin.png","NB :","Apabila terjadi kesalahan dalam pencatatan segera hubungi bagian Tata Usaha dengan menunjukkan bukti. Terima kasih");


DROP TABLE IF EXISTS `tb_jenis_tagihan`;

CREATE TABLE `tb_jenis_tagihan` (
  `id_jenis_tagihan` int(11) NOT NULL AUTO_INCREMENT,
  `jenis_tagihan` varchar(55) NOT NULL,
  `kelas` varchar(10) NOT NULL,
  `jurusan` varchar(25) NOT NULL,
  `jumlah` varchar(20) NOT NULL,
  PRIMARY KEY (`id_jenis_tagihan`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `tb_jenis_tagihan_siswa`;

CREATE TABLE `tb_jenis_tagihan_siswa` (
  `id_jns_tghn_siswa` int(11) NOT NULL AUTO_INCREMENT,
  `jenis_tagihan_siswa` varchar(55) NOT NULL,
  PRIMARY KEY (`id_jns_tghn_siswa`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `tb_jurusan`;

CREATE TABLE `tb_jurusan` (
  `id_jurusan` int(11) NOT NULL AUTO_INCREMENT,
  `jurusan` varchar(50) NOT NULL,
  PRIMARY KEY (`id_jurusan`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `tb_kelas`;

CREATE TABLE `tb_kelas` (
  `id_kelas` int(11) NOT NULL AUTO_INCREMENT,
  `kelas` varchar(25) NOT NULL,
  PRIMARY KEY (`id_kelas`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `tb_pembayaran`;

CREATE TABLE `tb_pembayaran` (
  `id_pembayaran` int(11) NOT NULL AUTO_INCREMENT,
  `id_siswa` int(11) DEFAULT NULL,
  `id_jenis_tagihan` varchar(11) DEFAULT NULL,
  `id_jns_tghn_siswa` varchar(11) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `jumlah` int(50) DEFAULT NULL,
  `chart` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id_pembayaran`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `tb_semester`;

CREATE TABLE `tb_semester` (
  `id_semester` int(11) NOT NULL AUTO_INCREMENT,
  `semester` varchar(50) NOT NULL,
  PRIMARY KEY (`id_semester`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `tb_siswa`;

CREATE TABLE `tb_siswa` (
  `id_siswa` int(11) NOT NULL AUTO_INCREMENT,
  `nis` varchar(11) NOT NULL,
  `nama_siswa` varchar(50) NOT NULL,
  `kelas` varchar(11) NOT NULL,
  `jurusan` varchar(100) NOT NULL,
  `foto` varchar(50) NOT NULL,
  PRIMARY KEY (`id_siswa`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `tb_tagihan_siswa`;

CREATE TABLE `tb_tagihan_siswa` (
  `id_tagihan_siswa` int(11) NOT NULL AUTO_INCREMENT,
  `id_siswa` int(11) NOT NULL,
  `id_jns_tghn_siswa` int(11) NOT NULL,
  `jumlah` varchar(20) NOT NULL,
  PRIMARY KEY (`id_tagihan_siswa`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `tb_tahun`;

CREATE TABLE `tb_tahun` (
  `id_tahun` int(11) NOT NULL AUTO_INCREMENT,
  `tahun` varchar(50) NOT NULL,
  PRIMARY KEY (`id_tahun`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `tb_user`;

CREATE TABLE `tb_user` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nama_user` varchar(50) NOT NULL,
  `level` enum('admin','user') NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO tb_user VALUES("1","admin","$2y$10$Ebzw8C0PAgWOS71kfi8x7.PiEE/XLH32AmGRTjC0saL0DvollTRLS","Administrator","admin");


SET foreign_key_checks = 1;
